<?php $__env->startSection('maincontent'); ?>

<div id="config">
<ul>
    <li><a href="<?php echo url('/'); ?>/title">Change Title</a></li>
    <li><a href="<?php echo url('/'); ?>/logo">Change Logo</a></li>
</ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>