<?php
function success_message($str){
    if($str == ''){
        return '';
    } else {
        return "<div class='s_msg'>".$str."</div>";
    }
}

function error_message($str){
    if($str == ''){
        return '';
    } else {
        return "<div class='e_msg'>".$str."</div>";
    }
}