<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Config;
use DB;
use Session;

class ConfigController extends Controller
{
    public function config_home(){
        $title = "App Config";
        return view('config.config_home', ['title' => $title]);
    }
    
    
    
    
}
