$(document).ready(function(){
   $(".s_msg, .e_msg").on("click", function(){
       $(this).fadeOut("slow");
   });
});