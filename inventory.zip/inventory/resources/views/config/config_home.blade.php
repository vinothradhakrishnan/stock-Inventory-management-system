@extends('home')

@section('maincontent')

<div id="config">
<ul>
    <li><a href="<?php echo url('/'); ?>/title">Change Title</a></li>
    <li><a href="<?php echo url('/'); ?>/logo">Change Logo</a></li>
</ul>
</div>
@endsection