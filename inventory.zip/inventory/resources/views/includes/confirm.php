<div id="confirm_background"></div>
<div id="confirm_box">
    <div id="confirm_box_head"></div>
    <div id="confirm_box_body"></div>
    <div id="confirm_box_footer"></div>
</div>
