->settings

-search product
->search By category | Brand | Product Name | Supplier Name

